# 🏡 家庭 AI 助手 — iPhone 适配版

这是一个适合 iPhone Safari 和电脑浏览器的家庭共享 GPT 聊天网页。它不是 iOS 原生 App，不需要上架 App Store。部署后，家人可以通过网址访问，也可以在 Safari 中添加网页图标到主屏幕（需要联网）。

## 功能
- 手机窄屏适配、16px 输入框字体以减少 iOS Safari 自动放大、支持安全区域底部间距
- 自动置底聊天输入框、可滚动长代码块、收起的设置侧栏
- 家庭密码进入（共享密码，不是独立用户账户）
- 各浏览器会话的聊天内容单独保存，不跨设备同步；刷新/断线可能丢失
- 每次会话最多 40 次请求的软限制；**不是服务端全局额度控制**
- API Key 只放在服务器 Secrets，不会直接暴露到浏览器

## 费用与安全重要提醒
- ChatGPT Plus/Pro 等订阅不能充当 OpenAI API 额度。API 需要另开通并按用量收费。
- 请在 https://platform.openai.com/usage 监控用量，并在项目中配置预算提醒或可用的限额。**预算并不一定是硬性止付措施。**
- 本项目只是面向少数可信家人的轻量示例，不适合公开运营；家庭密码可被重复猜测（本代码的尝试次数计数只能限制单次网页会话）。若需公开部署，建议使用可信身份验证、服务端持久化速率限制、滥用监控。
- 不要把 API Key 或家庭密码提交到 GitHub，不要将密钥发送给家人。

## 本地运行
需要 Python 3.10+。在项目目录终端执行：

```bash
python -m pip install -r requirements.txt
```

复制 `.streamlit/secrets.example.toml` 为 `.streamlit/secrets.toml`，修改为真实配置。务必不要上传 `secrets.toml`。

```toml
OPENAI_API_KEY = "你的OpenAI API Key"
FAMILY_PASSWORD = "长度足够的家庭密码"
OPENAI_MODEL = "gpt-6-luna"
```

然后运行：

```bash
python -m streamlit run app.py
```

网页通常会在 `http://localhost:8501` 打开；这个本地地址只能在你的电脑上访问。要让家人从外面访问，需要部署在线。

## 发布给家人访问（Streamlit Community Cloud）

1. 登录 GitHub：https://github.com ，新建仓库并上传本目录中的 `app.py`、`requirements.txt`、`README.md`、`.gitignore`、`.streamlit/secrets.example.toml`。**不要上传真实的 `.streamlit/secrets.toml`。**
2. 登录：https://share.streamlit.io ，选择创建 App 并连接 GitHub 仓库。
3. Main file path 填 `app.py`。
4. 在部署的 Advanced settings / Secrets 中填入真实配置（复制上面的 TOML 并替换值）。
5. 部署成功后得到类似 `https://your-app.streamlit.app` 的网址，把网址和家庭密码单独发送给受邀家人。
6. 在 iPhone Safari 打开网址，登录后就可以聊天。

## iPhone 添加到主屏幕

1. 用 iPhone 自带的 **Safari** 打开你部署好的 `https://...streamlit.app` 网站。
2. 点 Safari 的 **分享** 图标（方框向上箭头），找到 **添加到主屏幕**。不同 iOS 版本的菜单位置可能略有区别。
3. 点 **添加**。以后从主屏幕图标打开，就像打开一个网页快捷方式一样。

注意：这是网页快捷方式，**不是原生 iOS 安装包，也不支持离线 AI 聊天**。如果 Safari 没有“添加到主屏幕”，请确认网页在 Safari 而不是第三方应用内置浏览器中打开。

## 目录结构

```text
family-gpt/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── .streamlit/
    ├── config.toml
    └── secrets.example.toml
```
